﻿namespace BLE_Sample
{
    partial class mainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnConnect = new System.Windows.Forms.Button();
            this.charListBox = new System.Windows.Forms.ListBox();
            this.btnYLED = new System.Windows.Forms.Button();
            this.btnCLED = new System.Windows.Forms.Button();
            this.btnRLED = new System.Windows.Forms.Button();
            this.PetorneDeviceListBox = new System.Windows.Forms.ListBox();
            this.btnTakeOff = new System.Windows.Forms.Button();
            this.btnEmergencyStop = new System.Windows.Forms.Button();
            this.btnLanding = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.ProgressStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.btnRead = new System.Windows.Forms.Button();
            this.LogTextBox = new System.Windows.Forms.RichTextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnTimer = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.richTextBox8 = new System.Windows.Forms.RichTextBox();
            this.richTextBox9 = new System.Windows.Forms.RichTextBox();
            this.AccX = new System.Windows.Forms.Label();
            this.AccY = new System.Windows.Forms.Label();
            this.AccZ = new System.Windows.Forms.Label();
            this.gyroRoll = new System.Windows.Forms.Label();
            this.gyroPitch = new System.Windows.Forms.Label();
            this.gyroYaw = new System.Windows.Forms.Label();
            this.Roll = new System.Windows.Forms.Label();
            this.Pitch = new System.Windows.Forms.Label();
            this.Yaw = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_ho = new System.Windows.Forms.Button();
            this.bt_free = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(375, 12);
            this.btnConnect.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(131, 65);
            this.btnConnect.TabIndex = 3;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.Connect_Click);
            // 
            // charListBox
            // 
            this.charListBox.ItemHeight = 15;
            this.charListBox.Items.AddRange(new object[] {
            "No Petrone Selected",
            "Connect and Select Petorne"});
            this.charListBox.Location = new System.Drawing.Point(8, 12);
            this.charListBox.Margin = new System.Windows.Forms.Padding(2);
            this.charListBox.Name = "charListBox";
            this.charListBox.Size = new System.Drawing.Size(359, 64);
            this.charListBox.TabIndex = 2;
            // 
            // btnYLED
            // 
            this.btnYLED.Location = new System.Drawing.Point(374, 134);
            this.btnYLED.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnYLED.Name = "btnYLED";
            this.btnYLED.Size = new System.Drawing.Size(131, 34);
            this.btnYLED.TabIndex = 5;
            this.btnYLED.Text = "Dimming Yellow";
            this.btnYLED.UseVisualStyleBackColor = true;
            this.btnYLED.Click += new System.EventHandler(this.btnYLED_Click);
            // 
            // btnCLED
            // 
            this.btnCLED.Location = new System.Drawing.Point(374, 175);
            this.btnCLED.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCLED.Name = "btnCLED";
            this.btnCLED.Size = new System.Drawing.Size(131, 34);
            this.btnCLED.TabIndex = 6;
            this.btnCLED.Text = "색변경";
            this.btnCLED.UseVisualStyleBackColor = true;
            this.btnCLED.Click += new System.EventHandler(this.btnCLED_Click);
            // 
            // btnRLED
            // 
            this.btnRLED.Location = new System.Drawing.Point(374, 92);
            this.btnRLED.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRLED.Name = "btnRLED";
            this.btnRLED.Size = new System.Drawing.Size(131, 34);
            this.btnRLED.TabIndex = 7;
            this.btnRLED.Text = "Dimming RED";
            this.btnRLED.UseVisualStyleBackColor = true;
            this.btnRLED.Click += new System.EventHandler(this.btnRLED_Click);
            // 
            // PetorneDeviceListBox
            // 
            this.PetorneDeviceListBox.ItemHeight = 15;
            this.PetorneDeviceListBox.Location = new System.Drawing.Point(8, 92);
            this.PetorneDeviceListBox.Margin = new System.Windows.Forms.Padding(2);
            this.PetorneDeviceListBox.Name = "PetorneDeviceListBox";
            this.PetorneDeviceListBox.Size = new System.Drawing.Size(359, 79);
            this.PetorneDeviceListBox.TabIndex = 8;
            this.PetorneDeviceListBox.SelectedIndexChanged += new System.EventHandler(this.PetroneDeviceListBox_SelectedIndexChanged);
            // 
            // btnTakeOff
            // 
            this.btnTakeOff.Location = new System.Drawing.Point(375, 351);
            this.btnTakeOff.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTakeOff.Name = "btnTakeOff";
            this.btnTakeOff.Size = new System.Drawing.Size(131, 34);
            this.btnTakeOff.TabIndex = 11;
            this.btnTakeOff.Text = "Take Off";
            this.btnTakeOff.UseVisualStyleBackColor = true;
            this.btnTakeOff.Click += new System.EventHandler(this.btnTakeOff_Click);
            // 
            // btnEmergencyStop
            // 
            this.btnEmergencyStop.Location = new System.Drawing.Point(1025, 411);
            this.btnEmergencyStop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnEmergencyStop.Name = "btnEmergencyStop";
            this.btnEmergencyStop.Size = new System.Drawing.Size(131, 34);
            this.btnEmergencyStop.TabIndex = 10;
            this.btnEmergencyStop.Text = "주행";
            this.btnEmergencyStop.UseVisualStyleBackColor = true;
            this.btnEmergencyStop.Click += new System.EventHandler(this.btnEmergencyStop_Click);
            // 
            // btnLanding
            // 
            this.btnLanding.Location = new System.Drawing.Point(375, 392);
            this.btnLanding.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLanding.Name = "btnLanding";
            this.btnLanding.Size = new System.Drawing.Size(131, 34);
            this.btnLanding.TabIndex = 9;
            this.btnLanding.Text = "Landing";
            this.btnLanding.UseVisualStyleBackColor = true;
            this.btnLanding.Click += new System.EventHandler(this.btnLanding_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ProgressStatusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 474);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 16, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1316, 25);
            this.statusStrip1.TabIndex = 12;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // ProgressStatusLabel
            // 
            this.ProgressStatusLabel.Name = "ProgressStatusLabel";
            this.ProgressStatusLabel.Size = new System.Drawing.Size(66, 20);
            this.ProgressStatusLabel.Text = "Progress";
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(375, 222);
            this.btnRead.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(131, 34);
            this.btnRead.TabIndex = 13;
            this.btnRead.Text = "Read";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // LogTextBox
            // 
            this.LogTextBox.HideSelection = false;
            this.LogTextBox.Location = new System.Drawing.Point(8, 180);
            this.LogTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LogTextBox.Name = "LogTextBox";
            this.LogTextBox.Size = new System.Drawing.Size(358, 286);
            this.LogTextBox.TabIndex = 14;
            this.LogTextBox.Text = "";
            this.LogTextBox.TextChanged += new System.EventHandler(this.LogTextBox_TextChanged);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnTimer
            // 
            this.btnTimer.Location = new System.Drawing.Point(375, 264);
            this.btnTimer.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTimer.Name = "btnTimer";
            this.btnTimer.Size = new System.Drawing.Size(131, 34);
            this.btnTimer.TabIndex = 15;
            this.btnTimer.Text = "Timer";
            this.btnTimer.UseVisualStyleBackColor = true;
            this.btnTimer.Click += new System.EventHandler(this.btnTimer_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.HideSelection = false;
            this.richTextBox1.Location = new System.Drawing.Point(604, 12);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(131, 34);
            this.richTextBox1.TabIndex = 16;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // richTextBox2
            // 
            this.richTextBox2.HideSelection = false;
            this.richTextBox2.Location = new System.Drawing.Point(604, 67);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(131, 34);
            this.richTextBox2.TabIndex = 17;
            this.richTextBox2.Text = "";
            this.richTextBox2.TextChanged += new System.EventHandler(this.richTextBox2_TextChanged);
            // 
            // richTextBox3
            // 
            this.richTextBox3.HideSelection = false;
            this.richTextBox3.Location = new System.Drawing.Point(604, 121);
            this.richTextBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(131, 34);
            this.richTextBox3.TabIndex = 18;
            this.richTextBox3.Text = "";
            // 
            // richTextBox4
            // 
            this.richTextBox4.HideSelection = false;
            this.richTextBox4.Location = new System.Drawing.Point(852, 11);
            this.richTextBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(131, 34);
            this.richTextBox4.TabIndex = 19;
            this.richTextBox4.Text = "";
            this.richTextBox4.TextChanged += new System.EventHandler(this.richTextBox4_TextChanged);
            // 
            // richTextBox5
            // 
            this.richTextBox5.HideSelection = false;
            this.richTextBox5.Location = new System.Drawing.Point(852, 67);
            this.richTextBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.Size = new System.Drawing.Size(131, 34);
            this.richTextBox5.TabIndex = 20;
            this.richTextBox5.Text = "";
            // 
            // richTextBox6
            // 
            this.richTextBox6.HideSelection = false;
            this.richTextBox6.Location = new System.Drawing.Point(852, 124);
            this.richTextBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.Size = new System.Drawing.Size(131, 34);
            this.richTextBox6.TabIndex = 21;
            this.richTextBox6.Text = "";
            // 
            // richTextBox7
            // 
            this.richTextBox7.HideSelection = false;
            this.richTextBox7.Location = new System.Drawing.Point(604, 243);
            this.richTextBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.Size = new System.Drawing.Size(131, 34);
            this.richTextBox7.TabIndex = 22;
            this.richTextBox7.Text = "";
            // 
            // richTextBox8
            // 
            this.richTextBox8.HideSelection = false;
            this.richTextBox8.Location = new System.Drawing.Point(604, 300);
            this.richTextBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.richTextBox8.Name = "richTextBox8";
            this.richTextBox8.Size = new System.Drawing.Size(131, 34);
            this.richTextBox8.TabIndex = 23;
            this.richTextBox8.Text = "";
            // 
            // richTextBox9
            // 
            this.richTextBox9.HideSelection = false;
            this.richTextBox9.Location = new System.Drawing.Point(604, 357);
            this.richTextBox9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.richTextBox9.Name = "richTextBox9";
            this.richTextBox9.Size = new System.Drawing.Size(131, 34);
            this.richTextBox9.TabIndex = 24;
            this.richTextBox9.Text = "";
            // 
            // AccX
            // 
            this.AccX.AutoSize = true;
            this.AccX.Location = new System.Drawing.Point(542, 15);
            this.AccX.Name = "AccX";
            this.AccX.Size = new System.Drawing.Size(56, 15);
            this.AccX.TabIndex = 28;
            this.AccX.Text = "AccX : ";
            this.AccX.Click += new System.EventHandler(this.Acc_Click);
            // 
            // AccY
            // 
            this.AccY.AutoSize = true;
            this.AccY.Location = new System.Drawing.Point(542, 70);
            this.AccY.Name = "AccY";
            this.AccY.Size = new System.Drawing.Size(55, 15);
            this.AccY.TabIndex = 29;
            this.AccY.Text = "AccY : ";
            this.AccY.Click += new System.EventHandler(this.label1_Click);
            // 
            // AccZ
            // 
            this.AccZ.AutoSize = true;
            this.AccZ.Location = new System.Drawing.Point(542, 124);
            this.AccZ.Name = "AccZ";
            this.AccZ.Size = new System.Drawing.Size(56, 15);
            this.AccZ.TabIndex = 30;
            this.AccZ.Text = "AccZ : ";
            this.AccZ.Click += new System.EventHandler(this.label2_Click);
            // 
            // gyroRoll
            // 
            this.gyroRoll.AutoSize = true;
            this.gyroRoll.Location = new System.Drawing.Point(770, 14);
            this.gyroRoll.Name = "gyroRoll";
            this.gyroRoll.Size = new System.Drawing.Size(76, 15);
            this.gyroRoll.TabIndex = 31;
            this.gyroRoll.Text = "gyroRoll : ";
            this.gyroRoll.Click += new System.EventHandler(this.label3_Click);
            // 
            // gyroPitch
            // 
            this.gyroPitch.AutoSize = true;
            this.gyroPitch.Location = new System.Drawing.Point(762, 70);
            this.gyroPitch.Name = "gyroPitch";
            this.gyroPitch.Size = new System.Drawing.Size(84, 15);
            this.gyroPitch.TabIndex = 32;
            this.gyroPitch.Text = "gyroPitch : ";
            this.gyroPitch.Click += new System.EventHandler(this.label4_Click);
            // 
            // gyroYaw
            // 
            this.gyroYaw.AutoSize = true;
            this.gyroYaw.Location = new System.Drawing.Point(769, 124);
            this.gyroYaw.Name = "gyroYaw";
            this.gyroYaw.Size = new System.Drawing.Size(77, 15);
            this.gyroYaw.TabIndex = 33;
            this.gyroYaw.Text = "gyroYaw : ";
            this.gyroYaw.Click += new System.EventHandler(this.label5_Click);
            // 
            // Roll
            // 
            this.Roll.AutoSize = true;
            this.Roll.Location = new System.Drawing.Point(542, 246);
            this.Roll.Name = "Roll";
            this.Roll.Size = new System.Drawing.Size(47, 15);
            this.Roll.TabIndex = 34;
            this.Roll.Text = "Roll : ";
            this.Roll.Click += new System.EventHandler(this.Roll_Click);
            // 
            // Pitch
            // 
            this.Pitch.AutoSize = true;
            this.Pitch.Location = new System.Drawing.Point(542, 303);
            this.Pitch.Name = "Pitch";
            this.Pitch.Size = new System.Drawing.Size(55, 15);
            this.Pitch.TabIndex = 35;
            this.Pitch.Text = "Pitch : ";
            this.Pitch.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // Yaw
            // 
            this.Yaw.AutoSize = true;
            this.Yaw.Location = new System.Drawing.Point(542, 360);
            this.Yaw.Name = "Yaw";
            this.Yaw.Size = new System.Drawing.Size(48, 15);
            this.Yaw.TabIndex = 36;
            this.Yaw.Text = "Yaw : ";
            this.Yaw.Click += new System.EventHandler(this.Yaw_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(805, 236);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(178, 34);
            this.button1.TabIndex = 38;
            this.button1.Text = "Chart";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(805, 293);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(178, 34);
            this.button2.TabIndex = 39;
            this.button2.Text = "Image";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_ho
            // 
            this.btn_ho.Location = new System.Drawing.Point(557, 411);
            this.btn_ho.Name = "btn_ho";
            this.btn_ho.Size = new System.Drawing.Size(178, 34);
            this.btn_ho.TabIndex = 40;
            this.btn_ho.Text = "호버링";
            this.btn_ho.UseVisualStyleBackColor = true;
            this.btn_ho.Click += new System.EventHandler(this.btn_ho_Click);
            // 
            // bt_free
            // 
            this.bt_free.Location = new System.Drawing.Point(805, 411);
            this.bt_free.Name = "bt_free";
            this.bt_free.Size = new System.Drawing.Size(178, 34);
            this.bt_free.TabIndex = 41;
            this.bt_free.Text = "자율주행";
            this.bt_free.UseVisualStyleBackColor = true;
            this.bt_free.Click += new System.EventHandler(this.bt_free_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1054, 15);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(178, 34);
            this.button3.TabIndex = 42;
            this.button3.Text = "FPV";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1054, 70);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(178, 34);
            this.button4.TabIndex = 43;
            this.button4.Text = "가드";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(1054, 124);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(178, 34);
            this.button5.TabIndex = 44;
            this.button5.Text = "no가드";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(1068, 303);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(178, 34);
            this.button6.TabIndex = 45;
            this.button6.Text = "초기화";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1316, 499);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.bt_free);
            this.Controls.Add(this.btn_ho);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Yaw);
            this.Controls.Add(this.Pitch);
            this.Controls.Add(this.Roll);
            this.Controls.Add(this.gyroYaw);
            this.Controls.Add(this.gyroPitch);
            this.Controls.Add(this.gyroRoll);
            this.Controls.Add(this.AccZ);
            this.Controls.Add(this.AccY);
            this.Controls.Add(this.AccX);
            this.Controls.Add(this.richTextBox9);
            this.Controls.Add(this.richTextBox8);
            this.Controls.Add(this.richTextBox7);
            this.Controls.Add(this.richTextBox6);
            this.Controls.Add(this.richTextBox5);
            this.Controls.Add(this.richTextBox4);
            this.Controls.Add(this.richTextBox3);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.btnTimer);
            this.Controls.Add(this.LogTextBox);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.btnTakeOff);
            this.Controls.Add(this.btnEmergencyStop);
            this.Controls.Add(this.btnLanding);
            this.Controls.Add(this.PetorneDeviceListBox);
            this.Controls.Add(this.btnRLED);
            this.Controls.Add(this.btnCLED);
            this.Controls.Add(this.btnYLED);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.charListBox);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "mainForm";
            this.Text = "Windows-Petrone BLE Connector (v150427)";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.ListBox charListBox;
        private System.Windows.Forms.Button btnYLED;
        private System.Windows.Forms.Button btnCLED;
        private System.Windows.Forms.Button btnRLED;
        private System.Windows.Forms.ListBox PetorneDeviceListBox;
        private System.Windows.Forms.Button btnTakeOff;
        private System.Windows.Forms.Button btnEmergencyStop;
        private System.Windows.Forms.Button btnLanding;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel ProgressStatusLabel;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.RichTextBox LogTextBox;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnTimer;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.RichTextBox richTextBox6;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.RichTextBox richTextBox8;
        private System.Windows.Forms.RichTextBox richTextBox9;
        private System.Windows.Forms.Label AccX;
        private System.Windows.Forms.Label AccY;
        private System.Windows.Forms.Label AccZ;
        private System.Windows.Forms.Label gyroRoll;
        private System.Windows.Forms.Label gyroPitch;
        private System.Windows.Forms.Label gyroYaw;
        private System.Windows.Forms.Label Roll;
        private System.Windows.Forms.Label Pitch;
        private System.Windows.Forms.Label Yaw;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_ho;
        private System.Windows.Forms.Button bt_free;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
    }
}

