﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using System.Windows.Forms;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Devices.Enumeration;
using Ble_Sample;
using EmguCV;


//namespace Protocol
//{
//
//}

namespace BLE_Sample
{
    public partial class mainForm : Form
    {
        #region Enum Region
        enum DataType
        {
            None = 0,
            // 시스템 정보
            Ping, ///< 통신 확인(reserve)
            Ack, ///< 데이터 수신에 대한 응답
            Error, ///< 오류(reserve, 비트 플래그는 추후에 지정)
            Request, ///< 지정한 타입의 데이터 요청
            Passcode, ///< 새로운 페어링 비밀 번호(페어링 비밀 번호 변경 시 사용)
            // 조종, 명령
            Control = 0x10, ///< 조종
            Command, ///< 명령
            Command2, ///< 다중 명령(2가지 설정을 동시에 변경)
            Command3, ///< 다중 명령(3가지 설정을 동시에 변경)
            // LED
            LedMode = 0x20, ///< LED 모드 지정
            LedMode2, ///< LED 모드 2개 지정
            LedModeCommand, ///< LED 모드, 커맨드
            LedModeCommandIr, ///< LED 모드, 커맨드, IR 데이터 송신
            LedModeColor, ///< LED 모드 3색 직접 지정
            LedModeColor2, ///< LED 모드 3색 직접 지정 2개
            LedEvent, ///< LED 이벤트
            LedEvent2, ///< LED 이벤트 2개,
            LedEventCommand, ///< LED 이벤트, 커맨드
            LedEventCommandIr, ///< LED 이벤트, 커맨드, IR 데이터 송신
            LedEventColor, ///< LED 이벤트 3색 직접 지정
            LedEventColor2, ///< LED 이벤트 3색 직접 지정 2개
            LedModeDefaultColor, ///< LED 초기 모드 3색 직접 지정
            LedModeDefaultColor2, ///< LED 초기 모드 3색 직접 지정 2개

            // 상태
            Address = 0x30, ///< IEEE address
            State, ///< 드론의 상태(비행 모드, 방위기준, 배터리량)
            Attitude, ///< 드론의 자세
            GyroBias, ///< 자이로 바이어스 값
            TrimAll, ///< 전체 트림
            TrimFlight, ///< 비행 트림
            TrimDrive, ///< 주행 트림
            CountFlight,            // 비행 관련 카운트 
            CountDrive,             // 주행 관련 카운트 

            // 데이터 송수신
            IrMessage = 0x40,       // IR 데이터 송수신

            // 센서 및 제어
            ImuRawAndAngle = 0x50,  // IMU Raw + Angle
            Pressure,               // 압력 센서 데이터
            ImageFlow,              // ImageFlow
            Button,                 // 버튼 입력
            Battery,                // 배터리
            Motor,                  // 모터 제어 및 현재 제어값 확인
            Temperature,            // 온도 데이터
            Range,                  // 거리 센서

            EndOfType
        };
        enum CommandType
        {
            None = 0, ///< 이벤트 없음
            // 설정
            ModePetrone = 0x10, ///< 페트론 동작 모드 전환
            // 제어
            Coordinate = 0x20, ///< 방위 기준 변경
            Trim, ///< 트림 변경
            FlightEvent, ///< 비행 이벤트 실행
            DriveEvent, ///< 주행 이벤트 실행
            Stop, ///< 정지
            ResetHeading = 0x50, ///< 방향을 리셋(앱솔루트 모드 일 때 현재 heading을 0도로 변경)
            ClearGyroBiasAndTrim, ///< 자이로 바이어스와 트림 설정 초기화

            //통신
            PairingActivate = 0x80, ///< 페어링 활성화
            PairingDeactivate, ///< 페어링 비활성화
            TerminateConnection, ///< 연결 종료
            // 요청
            Request = 0x90, ///< 지정한 타입의 데이터 요청
            EndOfType
        };
        enum ModePetrone
        {
            None = 0,
            Flight = 0x10, ///< 비행 모드(가드 포함)
            FlightNoGuard, ///< 비행 모드(가드 없음)
            FlightFPV, ///< 비행 모드(FPV)
            Drive = 0x20, ///< 주행 모드
            DriveFPV, ///< 주행 모드(FPV)
            Test = 0x30, ///< 테스트 모드
            EndOfType
        };
        enum Coordinate
        {
            None = 0,
            Absolute, ///< 고정 좌표계
            Relative, ///< 상대 좌표계
            EndOfType
        };
        enum Trim
        {
            None = 0,
            RollIncrease, ///< Roll 증가
            RollDecrease, ///< Roll 감소
            PitchIncrease, ///< Pitch 증가
            PitchDecrease, ///< Pitch 감소
            YawIncrease, ///< Yaw 증가
            YawDecrease, ///< Yaw 감소
            ThrottleIncrease, ///< Throttle 증가
            ThrottleDecrease, ///< Throttle 감소
            EndOfType
        };
        enum FlightEvent
        {
            None = 0,
            TakeOff, ///< 이륙
            FlipFront, ///< 회전
            FlipRear, ///< 회전
            FlipLeft, ///< 회전
            FlipRight, ///< 회전
            Stop, ///< 정지
            Landing, ///< 착륙
            Reverse, ///< 뒤집기
            Shot, ///< 미사일을 쏠 때 움직임
            UnderAttack, ///< 미사일을 맞을 때 움직임
            Square, ///< 정방향 돌기
            CircleLeft, ///< 왼쪽으로 회전
            CircleRight, ///< 오른쪽으로 회전
            Rotate180, ///< 180도 회전
            EndOfType
        };
        enum Request
        {
            // 상태
            Address = 0x30, ///< IEEE address
            State, ///< 드론의 상태(비행 모드, 방위기준, 배터리량)
            Attitude, ///< 드론의 자세(Vector)
            GyroBias, ///< 자이로 바이어스 값(Vector)
            TrimAll, ///< 전체 트림
            TrimFlight, ///< 비행 트림
            TrimDrive, ///< 주행 트림
        };

        enum LEDMode
        {
            None = 0,
            EyeNone = 0x10,
            EyeHold, ///< 지정한 색상을 계속 켬
            EyeMix, ///< 순차적으로 LED 색 변경
            EyeFlicker, ///< 깜빡임
            EyeFlickerDouble, ///< 깜빡임(두 번 깜빡이고 깜빡인 시간만큼 꺼짐)
            EyeDimming, ///< 밝기 제어하여 천천히 깜빡임
            ArmNone = 0x40,
            ArmHold, ///< 지정한 색상을 계속 켬
            ArmMix, ///< 순차적으로 LED 색 변경
            ArmFlicker, ///< 깜빡임
            ArmFlickerDouble, ///< 깜빡임(두 번 깜빡이고 깜빡인 시간만큼 꺼짐)
            ArmDimming, ///< 밝기 제어하여 천천히 깜빡임
            ArmFlow, ///< 앞에서 뒤로 흐름
            ArmFlowReverse, ///< 뒤에서 앞으로 흐름
            EndOfType
        };
        enum Colors
        {
            AliceBlue, AntiqueWhite, Aqua,
            Aquamarine, Azure, Beige,
            Bisque, Black, BlanchedAlmond,
            Blue, BlueViolet, Brown,
            BurlyWood, CadetBlue, Chartreuse,
            Chocolate, Coral, CornflowerBlue,
            Cornsilk, Crimson, Cyan,
            DarkBlue, DarkCyan, DarkGoldenRod,
            DarkGray, DarkGreen, DarkKhaki,
            DarkMagenta, DarkOliveGreen, DarkOrange,
            DarkOrchid, DarkRed, DarkSalmon,
            DarkSeaGreen, DarkSlateBlue, DarkSlateGray,
            DarkTurquoise, DarkViolet, DeepPink,
            DeepSkyBlue, DimGray, DodgerBlue,
            FireBrick, FloralWhite, ForestGreen,
            Fuchsia, Gainsboro, GhostWhite,
            Gold, GoldenRod, Gray,
            Green, GreenYellow, HoneyDew,
            HotPink, IndianRed, Indigo,
            Ivory, Khaki, Lavender,
            LavenderBlush, LawnGreen, LemonChiffon,
            LightBlue, LightCoral, LightCyan,
            LightGoldenRodYellow, LightGray, LightGreen,
            LightPink, LightSalmon, LightSeaGreen,
            LightSkyBlue, LightSlateGray, LightSteelBlue,
            LightYellow, Lime, LimeGreen,
            Linen, Magenta, Maroon,
            MediumAquaMarine, MediumBlue, MediumOrchid,
            MediumPurple, MediumSeaGreen, MediumSlateBlue,
            MediumSpringGreen, MediumTurquoise, MediumVioletRed,
            MidnightBlue, MintCream, MistyRose,
            Moccasin, NavajoWhite, Navy,
            OldLace, Olive, OliveDrab,
            Orange, OrangeRed, Orchid,
            PaleGoldenRod, PaleGreen, PaleTurquoise,
            PaleVioletRed, PapayaWhip, PeachPuff,
            Peru, Pink, Plum,
            PowderBlue, Purple, RebeccaPurple,
            Red, RosyBrown, RoyalBlue,
            SaddleBrown, Salmon, SandyBrown,
            SeaGreen, SeaShell, Sienna,
            Silver, SkyBlue, SlateBlue,
            SlateGray, Snow, SpringGreen,
            SteelBlue, Tan, Teal,
            Thistle, Tomato, Turquoise,
            Violet, Wheat, White,
            WhiteSmoke, Yellow, YellowGreen,
            EndOfType
        };
        enum ModeFlight
        {
            None = 0,
            Ready, ///< 비행 준비
            TakeOff, ///< 이륙 (Flight로 자동전환)
            Flight, ///< 비행
            Flip, ///< 회전
            Stop, ///< 강제 정지
            Landing, ///< 착륙
            Reverse, ///< 뒤집기
            Accident, ///< 사고 (Ready로 자동전환)
            Error, ///< 오류
            EndOfType
        };
        enum ModeDrive
        {
            None = 0,
            Ready, ///< 준비
            Start, ///< 출발
            Drive, ///< 주행Stop, ///< 강제 정지
            Accident, ///< 사고 (Ready로 자동전환)
            Error, ///< 오류
            EndOfType
        };
        enum Direction
        {
            None = 0,

            Left,
            Front,
            Right,
            Rear,

            EndOfType
        };
        enum SensorOrientation
        {
            None = 0,
            Normal, ///< 정상
            ReverseStart, ///< 뒤집히기 시작
            Reverse, ///< 뒤집힘
            EndOfType
        };

        int angle_red;

        #endregion
        #region Variables Region

        DeviceInformationCollection m_Ble_Profile_List;
        GattDeviceService m_Ble_Service;
        IReadOnlyList<GattCharacteristic> m_Ble_Characteristic_List;

        const String PETRONE_CUSTOM_SERVICE_UUID = "C320DF00-7891-11E5-8BCF-FEFF819CDC9F";

        #endregion
        #region initialize Region
        public mainForm()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ButtonEnableControl(false);
        }
        #endregion
        #region Connect Reigon
        private async void Connect_Click(object sender, EventArgs e)
        {
            await ScanPetrone();
        }

        private async Task ScanPetrone()
        {
            // Get Petrone Device List as Custom Service UUID 
            m_Ble_Profile_List = await DeviceInformation.FindAllAsync(GattDeviceService.GetDeviceSelectorFromUuid(new Guid(PETRONE_CUSTOM_SERVICE_UUID)));

            PetorneDeviceListBox.Items.Clear();
            foreach (var m_Ble_Profile in m_Ble_Profile_List)
            {
                PetorneDeviceListBox.Items.Add("[" + m_Ble_Profile.Name + "]");
            }
        }

        private async void PetroneDeviceListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (PetorneDeviceListBox.SelectedIndex != -1)
            {
                // m_Ble_Profile_List Service is composed of only Custom Service 
                m_Ble_Service = await GattDeviceService.FromIdAsync(m_Ble_Profile_List[PetorneDeviceListBox.SelectedIndex].Id);
                m_Ble_Characteristic_List = m_Ble_Service.GetAllCharacteristics();
                m_Ble_Characteristic_List[0].ValueChanged += Value_Changed_Event_Handler;
                await m_Ble_Characteristic_List[0].WriteClientCharacteristicConfigurationDescriptorAsync(GattClientCharacteristicConfigurationDescriptorValue.Notify);

                // Print Characteristics in a List Box
                charListBox.Items.Clear();
                charListBox.Items.Add(m_Ble_Service.Device.Name);
                foreach (var m_Ble_Characteristic in m_Ble_Characteristic_List)
                {
                    charListBox.Items.Add(m_Ble_Characteristic.Uuid.ToString());
                }
                ButtonEnableControl(true);
            }
        }
        #endregion

        #region Command Transfer Region
        // Command transfer of a byte array format.
        public async void TransferBleCommand(byte[] cmd)
        {
            // m_Ble_Characteristic_List[0] is C32DF01
            // m_Ble_Characteristic_List[1] is C32DF02
            if (m_Ble_Characteristic_List != null)
                await m_Ble_Characteristic_List[1].WriteValueAsync(cmd.AsBuffer(), GattWriteOption.WriteWithoutResponse);

            // check Rootin : Flag Petrone Busy 
            // Timer
        }

        private async void TransferBleNotifyCommand(byte[] cmd)
        {
            // m_Ble_Characteristic_List[0] is C32DF01
            // m_Ble_Characteristic_List[1] is C32DF02
            if (m_Ble_Characteristic_List != null)
            {
                await m_Ble_Characteristic_List[1].WriteValueAsync(cmd.AsBuffer(), GattWriteOption.WriteWithResponse);
            }
        }
        #endregion
        #region Command Received Region
        private void btnRead_Click(object sender, EventArgs e)
        {
            // 32 Attitude, ///< 드론의 자세(Vector)
            //33 GyroBias ///< 자이로 바이어스 값(Vector)
            TransferBleCommand(new byte[] { 0x11, 0x90, 0x50 });
            TransferBleCommand(new byte[] { 0x11, 0x51 });
            TransferBleCommand(new byte[] { 0x11, 0x90, 0x50 });

            // TransferBleCommand(new byte[] { 0x17, 0x90, 0x32 });

        }

        private void btn_ho_Click(object sender, EventArgs e)
        {
            TransferBleCommand(new byte[] { 0x11, 0x22, 0x01 });
            System.Threading.Thread.Sleep(1100);
            TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x00, 80 });
            System.Threading.Thread.Sleep(2000);
            TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x00, 0x00 });
            System.Threading.Thread.Sleep(7000);
            falling();


            //TransferBleCommand(new byte[] { 0x11, 0x22, 0x01 });                        //take off
            //System.Threading.Thread.Sleep(1000);

            //TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0, 20 });            //멈춰있기
            //System.Threading.Thread.Sleep(2000);
            //change();

            //TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0, 0xDD });

            //System.Threading.Thread.Sleep(1000);
            //change();
            //TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0, 0x00 });

            //System.Threading.Thread.Sleep(1000);
            //change();
            //TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x00, 0x00 });
            //System.Threading.Thread.Sleep(1000);
            //change();
            //TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x00, 0xDD });
            //System.Threading.Thread.Sleep(1000);
            //change();
            //TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x00, 0x00 });
            //System.Threading.Thread.Sleep(1000);
            //change();
            //TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x00, 0xFB });
            //System.Threading.Thread.Sleep(1000);
            //change();





        }

        void falling()
        {



            TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x00, 0xDD });
            System.Threading.Thread.Sleep(1000);

            TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x00, 0xDD });
            System.Threading.Thread.Sleep(500);

            TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x00, 0xDD });
            System.Threading.Thread.Sleep(500);


            TransferBleCommand(new byte[] { 0x11, 0x22, 0x07 });
        }
        void change()
        {
            double size_r = c_r - f_c_r;
            double size_p = c_p - f_c_p;

            if (size_r > 0.5)             //roll 클때 
            {
                TransferBleCommand(new byte[] { 0x10, 0xFD, 0x00, 0x00, 0x00 });
                System.Threading.Thread.Sleep(30);

            }
            else if (size_r < -0.5)       //roll 작을때
            {
                TransferBleCommand(new byte[] { 0x10, 0x01, 0x00, 0x00, 0x00 });
                System.Threading.Thread.Sleep(30);
            }

            if (size_p > 0.5)
            {

                TransferBleCommand(new byte[] { 0x10, 0x00, 0xFD, 0x00, 0x00 });
                System.Threading.Thread.Sleep(30);
            }
            else if (size_p < -0.5)
            {
                TransferBleCommand(new byte[] { 0x10, 0x00, 0x01, 0x00, 0x00 });
                System.Threading.Thread.Sleep(30);
            }
        //}
        //    if (c_y >= 0.3)
        //    {

        //       /* TransferBleCommand(new byte[] { (byte)DataType.Command, (byte)CommandType.Trim, (byte)Trim.YawDecrease });
        //        TransferBleCommand(new byte[] { (byte)DataType.LedMode, (byte)LEDMode.ArmHold, (byte)Colors.LightSeaGreen, 0x05 });
        //        TransferBleCommand(new byte[] { (byte)DataType.LedMode, (byte)LEDMode.EyeDimming, (byte)Colors.LightSalmon, 0x05 });*/
        //    }
        //    else if (c_y <= -0.3)
        //    {
        //       /* TransferBleCommand(new byte[] { (byte)DataType.Command, (byte)CommandType.Trim, (byte)Trim.YawIncrease });
        //        TransferBleCommand(new byte[] { (byte)DataType.LedMode, (byte)LEDMode.ArmHold, (byte)Colors.LightPink, 0x05 });
        //        TransferBleCommand(new byte[] { (byte)DataType.LedMode, (byte)LEDMode.EyeDimming, (byte)Colors.SkyBlue, 0x05 });*/
        //    }


        // 

    }
        int count = 0;
        int ackTime;
        private  double c_r;
        private  double c_p;
        private  double c_y;
        private int kkk=0;

        double f_c_r = 0;
        double f_c_p = 0;       //초기 상보필터
        double f_c_y = 0;

        private void Value_Changed_Event_Handler(GattCharacteristic sender, GattValueChangedEventArgs args)
        {

            byte[] receivedData = new byte[args.CharacteristicValue.Length];

            receivedData = args.CharacteristicValue.ToArray();

            Form1 a = new Form1();
            angle_red = a.Angle_red;

            if (receivedData[0] == 0x50)
            {

                //TransferBleCommand(new byte[] { 0x11, 0x51 });

                int a_x = BitConverter.ToInt16(receivedData, 1);
                int a_y = BitConverter.ToInt16(receivedData, 3);
                int a_z = BitConverter.ToInt16(receivedData, 5);

                int g_r = BitConverter.ToInt16(receivedData, 7);
                int g_p = BitConverter.ToInt16(receivedData, 9);
                int g_y = BitConverter.ToInt16(receivedData, 11);

                int ang_r = BitConverter.ToInt16(receivedData, 13);
                int ang_p = BitConverter.ToInt16(receivedData, 15);
                int ang_y = BitConverter.ToInt16(receivedData, 17);

                //TransferBleCommand(new byte[] { 0x11, 0x51 });

                double a_roll = 0;
                //a_roll = 180 * Math.Atan(a_x/ (Math.Sqrt(a_y * a_y + a_z * a_z))) / Math.PI;
                a_roll = 180 * Math.Atan2(a_x, a_z) / Math.PI;

                double a_pitch = 0;
                //a_pitch = 180 * Math.Atan(a_y / (Math.Sqrt(a_x * a_x + a_z * a_z))) / Math.PI;
                a_pitch = 180 * Math.Atan2(a_y, a_z) / Math.PI;

                double a_yaw = 0;
                //a_yaw = 180 * Math.Atan((Math.Sqrt(a_x * a_x + a_y*a_y))/ a_z) / Math.PI;
                a_yaw = 180 * Math.Atan2(a_x, a_y) / Math.PI;

                //double acc_roll = 180 * Math.Atan2(a_x, a_z) / Math.PI;
                //double acc_pitch = 180 * Math.Atan2(a_y, a_z) / Math.PI;
                //double acc_yaw = 180 * Math.Atan2(a_x, a_y) / Math.PI;

                //Accurate Angle = (GyroPercentage) * Gyro Angle  + (1 - GryoPercentage) * Accel Angle
                //   double c_r = 0.95*g_r + 0.05*a_roll;
                //   double c_p = 0.95 * g_p + 0.05 * a_pitch;
                //   double c_y = 0.95 * g_y + 0.05 * a_yaw;

                //TransferBleCommand(new byte[] { 0x11, 0x51 });
                c_r = 0;
                c_r =  0.9925*(ang_r + (g_r * 0.001)) + 0.0075 * a_roll;
                c_p = 0;
                c_p = 0.9925 * (ang_p + (g_p * 0.001)) + 0.0075 * a_pitch;
                c_y = 0;
                c_y = (ang_y + (g_y* 0.001)) + 0.00045*a_z;
                if(count==0)
                {
                 f_c_r = c_r;
                    f_c_p = c_p;
                    f_c_y = c_y;

                }
                count++;

                //LogTextBox.AppendText(BitConverter.ToString(receivedData) + "\n");

                //LogTextBox.AppendText((System.DateTime.Now.Ticks - myTick) / 1000000 + " " + a + " " + b + " " + c + " " + d + " " + e + " " + f + "\n");
                /* LogTextBox.AppendText((System.DateTime.Now.Ticks - myTick) / 1000000
                     + "\n 가속도-     " + ang_r + "   " + ang_p + "   " + ang_y + " \n\n"
                     + " 자이로-       " + Math.Round(a_roll, 2) + "   " + Math.Round(a_pitch, 2) + "   " + Math.Round(a_yaw, 2) + " \n\n"
                  + "=======================================\n"
                     + "상보필터       " + Math.Round(c_r, 2) + "   " + Math.Round(c_p, 2) + "   " + Math.Round(c_y, 2) + " \n\n"
                 + "=======================================\n") ;*/
                //TransferBleCommand(new byte[] { 0x11, 0x51 });

                LogTextBox.AppendText(ackTime + " " + ang_r + " " + ang_p + " " + ang_y + "\n");
                richTextBox1.AppendText("\n" + a_x + " ");
                richTextBox2.AppendText("\n" + a_y + " ");
                richTextBox3.AppendText("\n" + a_z + " ");

                richTextBox4.AppendText("\n" + g_r + " ");
                richTextBox5.AppendText("\n" + g_p + " ");
                richTextBox6.AppendText("\n" + g_y + " ");

                richTextBox7.AppendText("\n" + Math.Round(c_r, 2) + " ");
                richTextBox8.AppendText("\n" + Math.Round(c_p, 2) + " ");
                richTextBox9.AppendText("\n" + Math.Round(c_y, 2) + " ");
              //  richTextBox10.AppendText("\n" +angle_red + " ");
                //TransferBleCommand(new byte[] { 0x11, 0x51 });





            }
            if (receivedData[0] == 0x21)
            { 
                int left = BitConverter.ToInt16(receivedData, 1);
                int front = BitConverter.ToInt16(receivedData, 3);
                int right = BitConverter.ToInt16(receivedData, 5);
                int rear = BitConverter.ToInt16(receivedData, 7);
                int top = BitConverter.ToInt16(receivedData, 9);
                int bottom = BitConverter.ToInt16(receivedData, 11);
                richTextBox1.AppendText("\n" + left + " ");
                richTextBox2.AppendText("\n" + front + " ");
                richTextBox3.AppendText("\n" + right + " ");

                richTextBox4.AppendText("\n" + rear + " ");
                richTextBox5.AppendText("\n" + top + " ");
                richTextBox6.AppendText("\n" + bottom + " ");
            }

            if (receivedData[0] == 0x02)
            {
                ackTime = BitConverter.ToInt32(receivedData, 1);
            }
            // save Time Stamp
            
        }
        #endregion

        #region Command Transfer Sample Reigon
        private void btnRLED_Click(object sender, EventArgs e)
        {
            TransferBleCommand(new byte[] { (byte)DataType.LedMode, (byte)LEDMode.ArmDimming, (byte)Colors.Red, 0x05 });
            TransferBleCommand(new byte[] { (byte)DataType.LedMode, (byte)LEDMode.EyeDimming, (byte)Colors.Red, 0x05 });
        }

        private void btnYLED_Click(object sender, EventArgs e)
        {
            TransferBleCommand(new byte[] { (byte)DataType.LedMode, (byte)LEDMode.ArmDimming, (byte)Colors.Yellow, 0x05 });
            TransferBleCommand(new byte[] { (byte)DataType.LedMode, (byte)LEDMode.EyeDimming, (byte)Colors.Yellow, 0x05 });
        }


        private void bt_free_Click(object sender, EventArgs e)
        {
            TransferBleCommand(new byte[] { (byte)DataType.Command, (byte)CommandType.FlightEvent, (byte)FlightEvent.TakeOff });
            System.Threading.Thread.Sleep(1000);
            TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x00, 0x07 });
            System.Threading.Thread.Sleep(1000);

            if (angle_red >= 80)
            {
                TransferBleCommand(new byte[] { 0x10, 0x00, 40, 0, 0x00 });
                System.Threading.Thread.Sleep(500);
            }
            else if (angle_red <= 80 && angle_red >= 60)
            {
                TransferBleCommand(new byte[] { 0x10, 0x00, 40, 0, 0x00 });
                System.Threading.Thread.Sleep(300);
                TransferBleCommand(new byte[] { 0x10, 0x00, 0, 30, 0x00 });
                System.Threading.Thread.Sleep(300);
            }
            else if (angle_red < 60 && angle_red >= 40)
            {
                TransferBleCommand(new byte[] { 0x10, 0x00, 40,0, 0x00 });
                System.Threading.Thread.Sleep(300);
                TransferBleCommand(new byte[] { 0x10, 0x00, 0, 50, 0x00 });
                System.Threading.Thread.Sleep(200);
            }
            else if (angle_red < 40 && angle_red >= 20)
            {
                TransferBleCommand(new byte[] { 0x10, 0x00, 40, 0, 0x00 });
                System.Threading.Thread.Sleep(300);
                TransferBleCommand(new byte[] { 0x10, 0x00, 0, 70, 0x00 });
                System.Threading.Thread.Sleep(300);
            }
       
       
            else if (angle_red < 20 && angle_red >= 0)
            {
                TransferBleCommand(new byte[] { 0x10, 0x00, 30, 0, 0x00 });
                System.Threading.Thread.Sleep(300);
                TransferBleCommand(new byte[] { 0x10, 0x00, 0, 85, 0x00 });
                System.Threading.Thread.Sleep(300);
            }
}


        
        private void btnCLED_Click(object sender, EventArgs e)
        {
            kkk = 1;
           
        }
        

        void right()
        {
            TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x80, 0x00 });
            System.Threading.Thread.Sleep(3000);

        }
        void left()
        {
            TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x9C, 0x00 });
            System.Threading.Thread.Sleep(3000);
        }
        private void btnTakeOff_Click(object sender, EventArgs e)
        {
            TransferBleCommand(new byte[] { (byte) DataType.Command, (byte) CommandType.FlightEvent, (byte) FlightEvent.TakeOff });
        }
        private void btnLanding_Click(object sender, EventArgs e)
        {
            falling();
           // TransferBleCommand(new byte[] { (byte)DataType.Command, (byte)CommandType.FlightEvent, (byte)FlightEvent.Landing });
        }
        private void btnEmergencyStop_Click(object sender, EventArgs e)
        {

            TransferBleCommand(new byte[] { (byte)DataType.Command, (byte)CommandType.FlightEvent, (byte)FlightEvent.TakeOff });
          
            System.Threading.Thread.Sleep(1000);

            TransferBleCommand(new byte[] { 0x10, 0x00, 60 ,0x00, 0x00 });
             System.Threading.Thread.Sleep(1500);
           
            TransferBleCommand(new byte[] { 0x10, 0x00, 0, 0XBB, 0x00 });
             System.Threading.Thread.Sleep(500);
             TransferBleCommand(new byte[] { 0x10, 0x00, 60, 0x00, 0x00 });
           System.Threading.Thread.Sleep(5000);
            TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 50, 0x00 });
            System.Threading.Thread.Sleep(500);
            TransferBleCommand(new byte[] { 0x10, 0x00, 60, 0x00, 0x00 });
            System.Threading.Thread.Sleep(2000);
           // TransferBleCommand(new byte[] { 0x10, 0x00, 0x10, 0XCC, 0x00 });
            System.Threading.Thread.Sleep(500);
            TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 50, 0x00 });
            System.Threading.Thread.Sleep(500);
            TransferBleCommand(new byte[] { 0x10, 0x00, 60, 0x00, 0x00 });
            System.Threading.Thread.Sleep(1000);
            falling();
           
            
            // TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x80, 0x00 });
            //System.Threading.Thread.Sleep(3000);
            // TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x9C, 0x00 });
            // System.Threading.Thread.Sleep(3000);
            //TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x00, 0x10 });
            //System.Threading.Thread.Sleep(3000);

            //TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x80, 0x00 });
            //System.Threading.Thread.Sleep(3000);

            //TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x00, 0xDD});
            //System.Threading.Thread.Sleep(3000);


            // TransferBleCommand(new byte[] { 0x10, 0x00, 0x00, 0x80, 0x00 });
            //System.Threading.Thread.Sleep(3000);

            //TransferBleCommand(new byte[] { 0x11, 0x22, 0x07 });
            //TransferBleCommand(new byte[] { (byte)DataType.Command, (byte)CommandType.FlightEvent, (byte)FlightEvent.Landing });

        }
        #endregion
        #region Etc Controller Reigon
        private void ButtonEnableControl(Boolean type)
        {
            btnConnect.Enabled = !type;
            btnRLED.Enabled = type;
            btnYLED.Enabled = type;
            btnCLED.Enabled = type;
            btnRead.Enabled = type;
            btnTakeOff.Enabled = type;
            btnLanding.Enabled = type;
            btnEmergencyStop.Enabled = type;
        }
        #endregion

        private void timer1_Tick(object sender, EventArgs e)
        {
            mySeq++;
            btnRead_Click(sender, e);
        }
        long myTick;
        int mySeq;
        private void btnTimer_Click(object sender, EventArgs e)
        {
            mySeq = 0;
            myTick = System.DateTime.Now.Ticks;
            if (timer1.Enabled == true)
                timer1.Enabled = false;
            else
                timer1.Enabled = true;
        }


       

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
        private void LogTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Acc_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void Roll_Click(object sender, EventArgs e)
        {

        }

        private void Yaw_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox4_TextChanged(object sender, EventArgs e)
        {
            
            
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Form2 a = new Form2();
            a.ShowDialog();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            
            a.ShowDialog();
            
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            TransferBleCommand(new byte[] { 0x11, 0x10, 0x12 });
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            TransferBleCommand(new byte[] { 0x11, 0x10, 0x10 });
        }

        private void button5_Click(object sender, EventArgs e)
        {
            TransferBleCommand(new byte[] { 0x11, 0x10, 0x11 });
        }

        private void button6_Click(object sender, EventArgs e)
        {
            TransferBleCommand(new byte[] { 0x11, 0x51 });
        }

        private void richTextBox10_TextChanged(object sender, EventArgs e)
        {

        }
    }

    /* private void button2_Click(object sender, EventArgs e)
{
    chart1.Series["Series1"].Points.Clear();
    chart1.Series["Series1"].Points.AddXY(10, 100);
    chart1.Series["Series1"].Points.AddXY(20, 200);
    chart1.Series["Series1"].Points.AddXY(30, 300);
    chart1.Series["Series1"].Points.AddXY(40, 400);
}

private void button3_Click(object sender, EventArgs e)
{

} */
    /* private void chart1_Click(object sender, EventArgs e)
         {

         }
     }*/
     }

