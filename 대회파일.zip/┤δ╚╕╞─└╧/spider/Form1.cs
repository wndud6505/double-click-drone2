﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.CV.CvEnum;
using Emgu.CV.Util;

namespace EmguCV
{
    public partial class Form1 : Form
    {
        Capture Source;
        public Form1()
        {
            InitializeComponent();
        }

        //Hue값은 0~359이나 8bit 저장을 위해 반으로 나누어(0~179) 사용한다 
        //Saturation과 Value 값은 0~100이나 8bit 저장을 위해 2.55를 곱해(0~255) 사용한다
        Hsv hsv_green_min = new Hsv(40, 110, 70);
        Hsv hsv_green_max = new Hsv(50, 135,90);

        Hsv hsv_blue_min = new Hsv(10, 150, 50);
        Hsv hsv_blue_max = new Hsv(45, 200, 250);

        Hsv hsv_red_min = new Hsv(40, 100, 00);
        Hsv hsv_red_max = new Hsv(70, 250, 150 );

      //  Hsv hsv_yel_min = new Hsv(20, 40, 0);
      //  Hsv hsv_yel_max = new Hsv(45, 100, 40);


        Hsv hsv_yel_min = new Hsv(50, 50, 100);
        Hsv hsv_yel_max = new Hsv(100, 90, 150);

        Hsv hsv_red_minU = new Hsv(50, 0,0);
        Hsv hsv_red_maxU = new Hsv(100, 0, 0);
        int angle_red;
        public int Angle_red
        {
            get { return angle_red; }
            set { angle_red = value; }
        }

        private void ImageProcessing(object sender, EventArgs e)
        {
            int mBlurParam = 10;
            int mCannyParam = 20;
            double cannyThreshold = 180.0;
            double cannyThresholdLinking = 120.0;


            int num1 = 0;       
            int num2 = 0;
            int num3 = 0;
            int count = 0;                    //
            int average = 0;
            int angle = 0;
            int big = 0;

            //영상 불러오기
            var mat = Source.QueryFrame();
            if (mat == null)
                return;
          
            //var OriginalImage = mat.ToImage<Bgr, Byte>();
            var BgrOImage = mat.ToImage<Bgr, Byte>();
            

            //RGB(BGR) -> HSV 
            var HsvOImage = mat.ToImage<Hsv, Byte>();
         //   imageBox2.Image = HsvOImage;

            ////Gaussian Bluring
            var BlurImage = HsvOImage.SmoothBlur(mBlurParam, mBlurParam);
         //   imageBox3.Image = BlurImage;

            Image<Gray, Byte> greenDest = HsvOImage.InRange(hsv_yel_min, hsv_yel_max);
          

            imageBox4.Image = greenDest;
            var kk = greenDest;
            Image<Gray, Byte> redDest = HsvOImage.InRange(hsv_red_min, hsv_red_max);

              Image<Gray, Byte> redDestU = HsvOImage.InRange(hsv_red_minU, hsv_red_maxU);

            Image<Gray, Byte> redDestSum = redDest+ redDestU;
            imageBox5.Image = redDestSum;

            // 원본과 흑백 영상
            var black = mat.ToImage<Gray, Byte>();
            var color = mat.ToImage<Bgr, Byte>();
            var Origin_green = black.CopyBlank();
            var Origin_red = black.CopyBlank();
            
            redDestSum._Dilate(15);
            redDestSum._Erode(15);
            UMat pyrDown = new UMat();
            CvInvoke.PyrDown(redDestSum, pyrDown);
            CvInvoke.PyrUp(pyrDown, redDestSum);
            Image<Gray, Byte> redDestSum_con = redDestSum.SmoothBlur(mBlurParam,mBlurParam).Canny(mCannyParam, mCannyParam);
   
            greenDest._Dilate(15);
            greenDest._Erode(3);
            CvInvoke.PyrDown(greenDest, pyrDown);
            CvInvoke.PyrUp(pyrDown, greenDest);
            Image<Gray, Byte> greenDest_con = greenDest.SmoothBlur(mBlurParam, mBlurParam).Canny(mCannyParam,mCannyParam);

         //   imageBox6.Image = greenDest_con;
          //  imageBox7.Image = redDestSum_con;
            
            UMat cannyEdges_green = new UMat();
            UMat cannyEdges_red = new UMat();
            Image<Bgr, Byte> lineImage_green_Line = color.CopyBlank();
            Image<Bgr, Byte> lineImage_red_Line = color.CopyBlank();
            Image<Bgr, Byte> lineImage_green = color.CopyBlank();
            Image<Bgr, Byte> lineImage_red = color.CopyBlank();

            //각각의 선 검출
            CvInvoke.Canny(greenDest_con, cannyEdges_green, cannyThreshold, cannyThresholdLinking);
            LineSegment2D[] lines_green = CvInvoke.HoughLinesP(cannyEdges_green, 1, Math.PI / 45.0, 50, 50, 100);
            CvInvoke.Canny(redDestSum_con, cannyEdges_red, cannyThreshold, cannyThresholdLinking);
            LineSegment2D[] lines_red = CvInvoke.HoughLinesP(cannyEdges_red, 1, Math.PI / 45.0, 50, 50, 100);

            //길이 비교에 따른 선 추출
            LineSegment2D Long_green = new LineSegment2D();
            foreach (LineSegment2D line in lines_green)
            {
                LineSegment2D Long_line = line;
                if (Long_line.Length > Long_green.Length)
                    Long_green = Long_line;    
            }
            lineImage_green_Line.Draw(Long_green, new Bgr(Color.Green), 6);
            LineSegment2D Long_red = new LineSegment2D();
            foreach (LineSegment2D line in lines_red)
            {
                LineSegment2D Long_line = line;
                if (Long_line.Length > Long_red.Length)                
                    Long_red = Long_line;       
            }

            lineImage_red_Line.Draw(Long_red, new Bgr(Color.Red), 6);
         //   imageBox8.Image = lineImage_green_Line;
            
           // imageBox9.Image = lineImage_red_Line;
            
            for (int i=0;i<BgrOImage.Cols;i++)
                for(int j=0; j < BgrOImage.Rows; j++)
                {
                  //  BgrOImage.
                }
            // 미분을 통한 각도 표시
            double dx_green = Long_green.P2.X - Long_green.P1.X;
            double dy_green = Long_green.P2.Y - Long_green.P1.Y;
            double slope_green = Math.Atan2(dy_green, dx_green);
            int angle_green = (int)(Math.Abs(slope_green * 180) / Math.PI);
            
            double dx_red = Long_red.P2.X - Long_red.P1.X;
            double dy_red = Long_red.P2.Y - Long_red.P1.Y;
            double slope_red = Math.Atan2(dy_red, dx_red);
           
               angle_red = (int)(Math.Abs(slope_red * 180) / Math.PI);


            num3 = angle_red;

            if (count >= 3)
            {
                average = (num3 + num2 + num1) / 3;

                big = Math.Abs(num3 - average);

                if (big >= 15)
                {
                    angle_red = num2;

                }
            }


            int cx = (int)(dx_red / 2 + Long_red.P2.X);
            int cy = (int)(dy_red / 2 + Long_red.P2.Y);
            int r = 2;
            double x = (cx + r * (Math.Cos(angle_green) * (Math.PI / 180)))/10;
            double y = cy + r * (Math.Sin(angle_green) * (Math.PI / 180));
            int t = cy;
            double yy =( 60 - y)/10;

            Triangle2DF tri = new Triangle2DF(new PointF((float)20, (float)40), new PointF((float)40, (float)40), new PointF((float)x, (float)yy));

            //  int cx = (int)(dx_red / 2 + Long_red.P1.X);
            //  int cy = (int)(dy_red / 2 + Long_red.P1.Y);
            //  int r = 2;
            //  double x = (cx + r * (Math.Cos(angle_red) * (Math.PI / 180))) / 5;
            //  double y = (cy + r * (Math.Sin(angle_red) * (Math.PI / 180))) / 5;
            //  int t = cy;

            ////  Triangle2DF tri = new Triangle2DF(new PointF((float)0, (float)x), new PointF((float)x, (float)y), new PointF((float)y, (float)0));
            //  Triangle2DF tri = new Triangle2DF(new PointF((float)0, (float)y), new PointF((float)x, (float)y), new PointF((float)x, (float)0));
            lineImage_green.Draw(Long_green, new Bgr(Color.Green), 2);

            //CvInvoke.PutText(lineImage_red, Convert.ToString(angle_red), new Point((int)(dx_red / 2 + Long_red.P1.X), (int)(dy_red / 2 + Long_red.P1.Y)), FontFace.HersheyComplex, 1.0, new Bgr(Color.Red).MCvScalar);

            BgrOImage.Draw(tri, new Bgr(Color.Red), 2);
            //  CvInvoke.PutText(BgrOImage, Convert.ToString(angle_green), new Point((int)(100), (int)(50)), FontFace.HersheyComplex, 2.0, new Bgr(Color.Black).MCvScalar);
            //  lineImage_green.Draw(Long_green, new Bgr(Color.Green), 2);
            // string n = "↗";
            // CvInvoke.PutText(BgrOImage, Convert.ToString(angle_red), new Point((int)(250), (int)(50)), FontFace.HersheyComplex, 1.0, new Bgr(Color.Blue).MCvScalar);
            // lineImage_red.Draw(Long_red, new Bgr(Color.Red), 2);
            // if (angle_red >= 0 && angle_red <20)
            //      CvInvoke.PutText(BgrOImage, Convert.ToString("West"), new Point((int)(10), (int)(200)), FontFace.HersheyComplex, 1.0, new Bgr(Color.Blue).MCvScalar);

            // if (angle_red >= 20 && angle_red < 80)
            //     CvInvoke.PutText(BgrOImage, Convert.ToString("North West"), new Point((int)(10), (int)(200)), FontFace.HersheyComplex, 1.0, new Bgr(Color.Blue).MCvScalar);

            //if (angle_red >= 80 && angle_red <= 90)
            //     CvInvoke.PutText(BgrOImage, Convert.ToString("North"), new Point((int)(10), (int)(200)), FontFace.HersheyComplex, 1.0, new Bgr(Color.Blue).MCvScalar);

            //imageBox10.Image = lineImage_green;
            //imageBox11.Image = lineImage_red ;

            count++;
            num1 = num2;
            num3 = num2;

            CvInvoke.PutText(BgrOImage, Convert.ToString("line    "+angle_red), new Point((int)(100), (int)(50)), FontFace.HersheyComplex, 1.0, new Bgr(Color.Blue).MCvScalar);
            CvInvoke.PutText(BgrOImage, Convert.ToString("finish  "+angle_green), new Point((int)(100), (int)(150)), FontFace.HersheyComplex, 1.0, new Bgr(Color.White).MCvScalar);
            // imageBox12.Image = lineImage_red + lineImage_green+ BgrOImage;
            imageBox1.Image = BgrOImage;
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                 Source = new Capture(@"rtsp://192.168.100.1/cam1/mpeg4");
               // Source = new Capture(@"6.MP4");
            // if (radioButton2.Checked)
            //   Source = new Capture(0);

            //if (radioButton3.Checked)
            //   Source = new Capture(@"11.mov");

            Application.Idle += ImageProcessing;
        }
        
        private void btnPause_Click(object sender, EventArgs e)
        {
            Application.Idle -= ImageProcessing;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void imageBox5_Click(object sender, EventArgs e)
        {

        }

        private void imageBox9_Click(object sender, EventArgs e)
        {

        }

        private void imageBox1_Click(object sender, EventArgs e)
        {

        }

        private void imageBox2_Click(object sender, EventArgs e)
        {

        }

        private void imageBox3_Click(object sender, EventArgs e)
        {

        }

        private void imageBox12_Click(object sender, EventArgs e)
        {

        }

        private void imageBox4_Click(object sender, EventArgs e)
        {

        }

        private void imageBox6_Click(object sender, EventArgs e)
        {

        }

        private void imageBox8_Click(object sender, EventArgs e)
        {

        }

        private void imageBox10_Click(object sender, EventArgs e)
        {

        }

   

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

  

    }
}
