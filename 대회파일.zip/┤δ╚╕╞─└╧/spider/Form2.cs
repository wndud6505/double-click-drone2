﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLE_Sample;
using System.Threading;
using System.Diagnostics;
using System.Windows.Forms.DataVisualization.Charting;

namespace Ble_Sample
{
    public partial class Form2 : Form
    {
        int mySeq;
        private int a_x, a_y, a_z;
        /*  private Thread cpuThread;
          private double[] cpuArray = new double[30];*/

        private void timer1_Tick(object sender, EventArgs e)
        {
            mySeq++;
        }

        public Form2()
        {
            InitializeComponent();
        }
        /*
        private void getPerformanceCounter()
        {
            var cpuPerfCounter = new PerformanceCounter("Processor Information", "% Processor Time", "_Total");

            while(true)
            {
                cpuArray[cpuArray.Length - 1] = Math.Round(cpuPerfCounter.NextValue(), 0);

                Array.Copy(cpuArray, 1, cpuArray, 0, cpuArray.Length - 1);

                if(cpuChart.IsHandleCreated)
                {
                    this.Invoke((MethodInvoker)delegate { UpdateCpuChart(); });
                }
                else
                { }
            }
        }*/

        private void Form1_Load(object sender, EventArgs e)
        {

            for (int i = 0; i < 1000; i++)
            {
                chart2.Series["가속도 센서 X"].Points.Add(mySeq, a_x);
                chart2.Series["가속도 센서 Y"].Points.Add(mySeq, a_y);
                chart2.Series["가속도 센서 Z"].Points.Add(mySeq, a_z);
            }

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void btnTimer_Click(object sender, EventArgs e)
        {

        }

        private void btnRead_Click(object sender, EventArgs e)
        {
         
        }
    /*    private void UpdateCpuChart()
        {   
            UpdateCpuChart.Series["Series1"].Points.Clear();

            for (int i = 0; i < cpuArray.Length - 1; ++i)
            {
                cpuChart.Series["series"].Points.AddY(cpuArray[i]);

            }*/
    }
}
